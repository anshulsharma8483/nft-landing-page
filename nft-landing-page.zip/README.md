# NFT Landing Page – Unlock The Digital Renaissance

This project is a static landing page created as part of a frontend assignment.
It is inspired by the provided design reference and built using **HTML and CSS only**.

## Features
- Clean semantic HTML
- CSS Grid & Flexbox layout
- Reference‑accurate typography & spacing
- No external libraries or frameworks
- Assignment‑safe CSS (no experimental properties)

## Folder Structure
```
.
├── index.html
├── style.css
├── README.md
└── assets (images)
```

## How to Run
1. Download or clone the repository
2. Open `index.html` in your browser

## Author
Student Assignment Project
